import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Initialize session or default to Student demo profile
  useEffect(() => {
    const initAuth = async () => {
      const savedToken = localStorage.getItem("helpdesk_token");
      if (savedToken) {
        try {
          const profile = await api.getMe();
          setUser(profile);
          setLoading(false);
          return;
        } catch (err) {
          console.warn("Saved token expired, resetting session.");
          localStorage.removeItem("helpdesk_token");
        }
      }

      // Default demo login as Student for instant usability
      try {
        const demoRes = await api.switchRole("student");
        localStorage.setItem("helpdesk_token", demoRes.access_token);
        setUser(demoRes.user);
      } catch (e) {
        console.error("Demo auth init error:", e);
      } finally {
        setLoading(false);
      }
    };

    initAuth();
  }, []);

  const login = async (email, password) => {
    setLoading(true);
    try {
      const res = await api.login(email, password);
      localStorage.setItem("helpdesk_token", res.access_token);
      setUser(res.user);
      return res.user;
    } finally {
      setLoading(false);
    }
  };

  const register = async (userData) => {
    setLoading(true);
    try {
      const res = await api.register(userData);
      localStorage.setItem("helpdesk_token", res.access_token);
      setUser(res.user);
      return res.user;
    } finally {
      setLoading(false);
    }
  };

  const switchDemoRole = async (role) => {
    setLoading(true);
    try {
      const res = await api.switchRole(role);
      localStorage.setItem("helpdesk_token", res.access_token);
      setUser(res.user);
      return res.user;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem("helpdesk_token");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, switchDemoRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
