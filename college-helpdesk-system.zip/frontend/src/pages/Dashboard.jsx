import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, 
  TicketCheck, 
  FileText, 
  Bell, 
  ArrowRight, 
  Clock, 
  AlertCircle,
  Building2,
  CheckCircle2,
  Bot,
  PlusCircle,
  Pin,
  Calendar,
  Layers
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import StatCard from '../components/StatCard';
import TicketModal from '../components/TicketModal';
import NoticeEditModal from '../components/NoticeEditModal';

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [analytics, setAnalytics] = useState(null);
  const [tickets, setTickets] = useState([]);
  const [notices, setNotices] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [quickQuery, setQuickQuery] = useState('');
  const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);
  const [isNoticeModalOpen, setIsNoticeModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [statsData, ticketsData, noticesData, deptsData] = await Promise.all([
          api.getAnalyticsOverview(),
          api.getTickets(),
          api.getNotices(),
          api.getDepartments()
        ]);
        setAnalytics(statsData);
        setTickets(ticketsData);
        setNotices(noticesData.slice(0, 4));
        setDepartments(deptsData.slice(0, 4));
      } catch (err) {
        console.error("Dashboard fetch error:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [user]);

  const handleQuickAsk = (e) => {
    e.preventDefault();
    if (quickQuery.trim()) {
      navigate('/chat', { state: { initialQuery: quickQuery } });
    }
  };

  const getPriorityColor = (p) => {
    switch (p) {
      case 'urgent': return 'text-rose-700 bg-rose-50 border-rose-200';
      case 'high': return 'text-amber-700 bg-amber-50 border-amber-200';
      case 'medium': return 'text-blue-700 bg-blue-50 border-blue-200';
      default: return 'text-slate-600 bg-slate-50 border-slate-200';
    }
  };

  const getStatusColor = (s) => {
    switch (s) {
      case 'open': return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'in_progress': return 'bg-blue-50 text-blue-800 border-blue-200';
      case 'resolved': return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Official College Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-900 text-white p-7 md:p-9 shadow-lg border border-blue-800">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-800/80 border border-blue-700 text-blue-200 text-xs font-semibold mb-4">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            AI-Powered Student Helpdesk & Knowledge Base
          </div>
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight">
            Welcome back, {user?.full_name?.split(' ')[0]} 👋
          </h2>
          <p className="text-sm text-blue-100 mt-2 leading-relaxed">
            Instant guidance on semester examinations, credit requirements, fee deadlines, hostel rules, and support tickets grounded in official college records.
          </p>

          <form onSubmit={handleQuickAsk} className="mt-6 flex items-center gap-2.5 max-w-xl">
            <div className="relative flex-1">
              <input
                type="text"
                value={quickQuery}
                onChange={(e) => setQuickQuery(e.target.value)}
                placeholder="Ask e.g. What is the attendance condonation criteria for semester exams?"
                className="w-full px-4 py-3 rounded-2xl bg-white text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400 shadow-sm"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-blue-950 text-xs font-bold flex items-center gap-2 shadow-md transition-all flex-shrink-0"
            >
              <Bot className="w-4 h-4" />
              <span>Ask AI</span>
            </button>
          </form>
        </div>

        {/* Subtle decorative crest ring */}
        <div className="absolute right-0 top-0 -mt-10 -mr-10 w-96 h-96 bg-blue-600/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Active Support Tickets"
          value={analytics ? analytics.open_tickets : '--'}
          subtitle="Awaiting response or resolution"
          icon={TicketCheck}
          color="amber"
          trend={{ label: 'Total Tickets', value: analytics?.total_tickets || 0, positive: true }}
        />
        <StatCard
          title="Indexed Regulations"
          value={analytics ? analytics.total_documents : '--'}
          subtitle={`${analytics?.total_chunks || 0} vector chunks ready`}
          icon={FileText}
          color="blue"
          trend={{ label: 'Status', value: '100% Vectorized', positive: true }}
        />
        <StatCard
          title="AI Queries Resolved"
          value={analytics ? analytics.total_queries : '--'}
          subtitle={`${analytics?.unanswered_queries || 0} flagged gaps`}
          icon={Sparkles}
          color="emerald"
          trend={{ label: 'Accuracy', value: `${analytics?.satisfaction_rate || 95}%`, positive: true }}
        />
        <StatCard
          title="Academic Departments"
          value={departments.length ? departments.length : 6}
          subtitle="Directory and faculty synced"
          icon={Building2}
          color="violet"
          trend={{ label: 'Portal', value: '24/7 Available', positive: true }}
        />
      </div>

      {/* Two Column Layout: Support Tickets & Campus Notices */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Support Tickets Queue (2 Columns) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <TicketCheck className="w-4 h-4 text-blue-700" />
                {user?.role === 'student' ? 'My Support Grievances' : 'Helpdesk Service Queue'}
              </h3>
              <p className="text-xs text-slate-500">Track student requests and departmental resolutions</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsTicketModalOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold shadow-sm"
              >
                + New Ticket
              </button>
              <button
                onClick={() => navigate('/tickets')}
                className="text-xs text-blue-900 font-semibold hover:underline flex items-center gap-1"
              >
                <span>View all</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100 shadow-sm">
            {tickets.length > 0 ? (
              tickets.slice(0, 4).map((ticket) => (
                <div
                  key={ticket.id}
                  onClick={() => navigate(`/tickets/${ticket.id}`)}
                  className="p-4 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between gap-4"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[11px] text-blue-900 bg-blue-50 px-2 py-0.5 rounded font-bold border border-blue-200">
                        {ticket.ticket_number}
                      </span>
                      <h4 className="text-xs font-bold text-slate-800 truncate">{ticket.title}</h4>
                    </div>
                    <div className="flex items-center gap-3 text-[11px] text-slate-500">
                      <span className="font-medium text-slate-700">{ticket.department_name}</span>
                      <span>•</span>
                      <span>{ticket.category}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1 font-mono">
                        <Clock className="w-3 h-3 text-slate-400" />
                        {new Date(ticket.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 flex-shrink-0">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase ${getPriorityColor(ticket.priority)}`}>
                      {ticket.priority}
                    </span>
                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border capitalize ${getStatusColor(ticket.status)}`}>
                      {ticket.status.replace('_', ' ')}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-slate-400 text-xs">
                No tickets submitted yet. Click "+ New Ticket" to create one.
              </div>
            )}
          </div>
        </div>

        {/* Campus Notices Column */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Bell className="w-4 h-4 text-amber-600" />
              Campus Circulars
            </h3>
            <div className="flex items-center gap-2">
              {user?.role !== 'student' && (
                <button
                  onClick={() => setIsNoticeModalOpen(true)}
                  className="text-xs text-blue-900 font-bold hover:underline"
                >
                  + Add
                </button>
              )}
              <button
                onClick={() => navigate('/notices')}
                className="text-xs text-slate-600 hover:text-slate-900 flex items-center gap-1"
              >
                <span>All</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-sm">
            {notices.map((n) => (
              <div
                key={n.id}
                onClick={() => navigate('/notices')}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/90 hover:border-blue-400 hover:bg-blue-50/30 transition-all cursor-pointer space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-900 border border-blue-200">
                    {n.category}
                  </span>
                  {n.is_pinned && (
                    <span className="text-[10px] text-amber-700 font-bold flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      <Pin className="w-3 h-3" /> Pinned
                    </span>
                  )}
                </div>
                <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{n.title}</h4>
                <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">{n.content}</p>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Ticket Modal */}
      <TicketModal
        isOpen={isTicketModalOpen}
        onClose={() => setIsTicketModalOpen(false)}
        onCreated={(newTicket) => {
          setTickets([newTicket, ...tickets]);
          if (analytics) {
            setAnalytics({
              ...analytics,
              total_tickets: analytics.total_tickets + 1,
              open_tickets: analytics.open_tickets + 1
            });
          }
        }}
      />

      {/* Notice Edit / Create Modal for Admin & Faculty */}
      <NoticeEditModal
        isOpen={isNoticeModalOpen}
        onClose={() => setIsNoticeModalOpen(false)}
        noticeToEdit={null}
        onSaved={(newNotice) => setNotices([newNotice, ...notices])}
      />

    </div>
  );
}
