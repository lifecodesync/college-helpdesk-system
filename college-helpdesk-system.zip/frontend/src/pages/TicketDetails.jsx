import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Send, 
  User, 
  Clock, 
  CheckCircle2, 
  Lock
} from 'lucide-react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function TicketDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [ticket, setTicket] = useState(null);
  const [loading, setLoading] = useState(true);
  const [commentText, setCommentText] = useState('');
  const [isInternal, setIsInternal] = useState(false);
  const [facultyList, setFacultyList] = useState([]);
  const [updating, setUpdating] = useState(false);
  const [resolutionNotes, setResolutionNotes] = useState('');

  const fetchTicket = async () => {
    try {
      const data = await api.getTicketById(id);
      setTicket(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTicket();
    if (user?.role !== 'student') {
      api.getUsers().then(users => {
        setFacultyList(users.filter(u => u.role === 'faculty' || u.role === 'admin'));
      }).catch(console.error);
    }
  }, [id, user]);

  const handleStatusChange = async (newStatus) => {
    setUpdating(true);
    try {
      const updated = await api.updateTicketStatus(id, newStatus, resolutionNotes || undefined);
      setTicket(updated);
      setResolutionNotes('');
    } catch (err) {
      console.error(err);
    } finally {
      setUpdating(false);
    }
  };

  const handleAssign = async (staffId) => {
    setUpdating(true);
    try {
      const updated = await api.assignTicket(id, staffId);
      setTicket(updated);
    } catch (err) {
      console.error(err);
    } finally {
      setUpdating(false);
    }
  };

  const handlePostComment = async (e) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    try {
      const newComment = await api.addComment(id, commentText, isInternal);
      setTicket(prev => ({
        ...prev,
        comments: [...prev.comments, newComment]
      }));
      setCommentText('');
      setIsInternal(false);
    } catch (err) {
      console.error("Comment post error:", err);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-xs text-slate-400">Loading ticket #{id}...</div>;
  }

  if (!ticket) {
    return (
      <div className="p-8 text-center text-xs text-rose-600 font-semibold">
        Ticket not found or unauthorized access.
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Back button */}
      <button
        onClick={() => navigate('/tickets')}
        className="flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-blue-900 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to all tickets</span>
      </button>

      {/* Main Ticket Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
        
        {/* Top Info Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="font-mono text-xs px-2.5 py-1 rounded-lg bg-blue-50 text-blue-900 border border-blue-200 font-bold">
                {ticket.ticket_number}
              </span>
              <span className="text-xs text-slate-500">Category: <strong className="text-slate-800">{ticket.category}</strong></span>
              <span className="text-xs text-slate-300">•</span>
              <span className="text-xs text-slate-500">Dept: <strong className="text-slate-800">{ticket.department_name}</strong></span>
            </div>
            <h1 className="text-lg md:text-xl font-extrabold text-slate-900 mt-2">{ticket.title}</h1>
            <p className="text-xs text-slate-500 mt-1 flex items-center gap-2">
              <span>Submitted by <strong className="text-slate-700">{ticket.student_name}</strong> ({ticket.student_roll || ticket.student_email})</span>
              <span>•</span>
              <span className="flex items-center gap-1 font-mono">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                {new Date(ticket.created_at).toLocaleString()}
              </span>
            </p>
          </div>

          {/* Status & Assignment Controls */}
          <div className="flex items-center gap-3 flex-wrap">
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-bold text-slate-400 block">Status</label>
              <select
                value={ticket.status}
                onChange={(e) => handleStatusChange(e.target.value)}
                disabled={updating || (user?.role === 'student' && ticket.status === 'closed')}
                className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-300 text-xs font-bold capitalize text-slate-800 focus:bg-white focus:outline-none focus:border-blue-600"
              >
                <option value="open">Open</option>
                <option value="in_progress">In Progress</option>
                <option value="resolved">Resolved</option>
                <option value="closed">Closed</option>
              </select>
            </div>

            {user?.role !== 'student' && (
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-slate-400 block">Assignee</label>
                <select
                  value={ticket.assigned_to || ""}
                  onChange={(e) => handleAssign(e.target.value)}
                  disabled={updating}
                  className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-300 text-xs font-semibold text-slate-800 focus:bg-white focus:outline-none focus:border-blue-600"
                >
                  <option value="">Unassigned</option>
                  {facultyList.map(f => (
                    <option key={f.id} value={f.id}>{f.full_name}</option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>

        {/* Problem Description */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Issue Details</h3>
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 leading-relaxed whitespace-pre-wrap">
            {ticket.description}
          </div>
        </div>

        {/* Resolution Notes if Resolved */}
        {ticket.resolution_notes && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1">
            <h4 className="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Official Department Resolution Note
            </h4>
            <p className="text-xs text-emerald-900 leading-relaxed">{ticket.resolution_notes}</p>
          </div>
        )}

        {/* Discussion Thread */}
        <div className="space-y-4 pt-4 border-t border-slate-200">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Discussion & Activity Log ({ticket.comments?.length || 0})
          </h3>

          <div className="space-y-3">
            {ticket.comments && ticket.comments.length > 0 ? (
              ticket.comments.map((comm) => (
                <div
                  key={comm.id}
                  className={`p-4 rounded-xl border text-xs space-y-1.5 ${
                    comm.is_internal
                      ? 'bg-amber-50/80 border-amber-200 text-amber-950'
                      : 'bg-white border-slate-200 text-slate-800 shadow-sm'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{comm.user_name}</span>
                      <span className="text-[10px] uppercase font-mono font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                        {comm.user_role}
                      </span>
                      {comm.is_internal && (
                        <span className="flex items-center gap-1 text-[10px] text-amber-800 font-bold bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                          <Lock className="w-3 h-3" /> Internal Faculty Note
                        </span>
                      )}
                    </div>
                    <span className="text-slate-400 font-mono">{new Date(comm.created_at).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-xs leading-relaxed">{comm.message}</p>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-400 py-3">No replies recorded on this ticket yet.</p>
            )}
          </div>

          {/* Add Reply Form */}
          <form onSubmit={handlePostComment} className="pt-2 space-y-3">
            <textarea
              rows={3}
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Type your official update, student clarification, or reply..."
              className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-300 text-xs text-slate-900 placeholder-slate-400 focus:bg-white focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
              required
            />

            <div className="flex items-center justify-between">
              {user?.role !== 'student' ? (
                <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isInternal}
                    onChange={(e) => setIsInternal(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                  />
                  <span>Mark as internal note (hidden from student)</span>
                </label>
              ) : <div />}

              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold shadow-md shadow-blue-900/20"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Post Reply</span>
              </button>
            </div>
          </form>

        </div>

      </div>

    </div>
  );
}
