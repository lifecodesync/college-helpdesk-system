import React, { useState, useEffect } from 'react';
import { 
  Menu, 
  X, 
  Sparkles, 
  ShieldCheck, 
  UserCheck, 
  GraduationCap, 
  LogOut,
  ChevronDown,
  Database
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import SupabaseModal from './SupabaseModal';

export default function Navbar({ toggleSidebar, isSidebarOpen }) {
  const { user, switchDemoRole, logout } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [supabaseModalOpen, setSupabaseModalOpen] = useState(false);
  const [supabaseStatus, setSupabaseStatus] = useState(null);

  useEffect(() => {
    api.getSupabaseStatus().then(setSupabaseStatus).catch(console.error);
  }, []);

  const handleRoleSwitch = async (role) => {
    setDropdownOpen(false);
    await switchDemoRole(role);
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 md:px-8 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm">
      
      {/* Mobile Toggle & Institutional Breadcrumb */}
      <div className="flex items-center gap-3">
        <button
          onClick={toggleSidebar}
          className="p-2 text-slate-500 hover:text-slate-900 rounded-lg md:hidden hover:bg-slate-100"
          aria-label="Toggle menu"
        >
          {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        <div className="hidden sm:flex items-center gap-2 text-xs">
          <span className="font-bold text-blue-900">NIET Campus</span>
          <span className="text-slate-300">/</span>
          <span className="font-medium text-slate-700 capitalize">{user?.role || 'Helpdesk'} Desk</span>
          <span className="text-slate-300">/</span>
          <span className="text-slate-500 font-mono text-[11px]">Academic Term 2026–27</span>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2.5 sm:gap-3">
        
        {/* Supabase Connection Status Pill */}
        <button
          onClick={() => setSupabaseModalOpen(true)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
            supabaseStatus?.connected
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
              : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
          }`}
          title="Click to view or configure Supabase Cloud Database"
        >
          <Database className="w-3.5 h-3.5" />
          <span className="hidden lg:inline">
            {supabaseStatus?.connected ? 'Supabase Connected' : 'Supabase (Local Mode)'}
          </span>
          <span className={`w-2 h-2 rounded-full ${supabaseStatus?.connected ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`} />
        </button>

        {/* Quick Role Switcher for Evaluation */}
        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 border border-slate-200">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-2 hidden md:inline">
            Role:
          </span>
          <button
            onClick={() => handleRoleSwitch('student')}
            className={`px-2.5 py-1 text-xs rounded-lg font-bold transition-all ${
              user?.role === 'student'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Student
          </button>
          <button
            onClick={() => handleRoleSwitch('faculty')}
            className={`px-2.5 py-1 text-xs rounded-lg font-bold transition-all ${
              user?.role === 'faculty'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Faculty
          </button>
          <button
            onClick={() => handleRoleSwitch('admin')}
            className={`px-2.5 py-1 text-xs rounded-lg font-bold transition-all ${
              user?.role === 'admin'
                ? 'bg-blue-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Admin
          </button>
        </div>

        {/* User Profile Pill & Dropdown */}
        <div className="relative">
          <button 
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-2 p-1.5 pr-2 rounded-xl hover:bg-slate-100 transition-colors border border-transparent hover:border-slate-200"
          >
            <img 
              src={user?.avatar_url || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"} 
              alt={user?.full_name} 
              className="w-7 h-7 rounded-lg object-cover ring-1 ring-slate-300"
            />
            <span className="text-xs font-bold text-slate-800 hidden md:inline max-w-[120px] truncate">
              {user?.full_name?.split(' ')[0]}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
          </button>

          {dropdownOpen && (
            <div className="absolute right-0 mt-2 w-60 rounded-2xl bg-white border border-slate-200 shadow-xl py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-4 py-2.5 border-b border-slate-100">
                <p className="text-xs font-bold text-slate-900 truncate">{user?.full_name}</p>
                <p className="text-[11px] text-slate-500 truncate">{user?.email}</p>
                <span className="inline-block mt-1.5 text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                  {user?.role} Tier
                </span>
              </div>

              <div className="p-1">
                <button
                  onClick={() => handleRoleSwitch('student')}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs text-left rounded-lg text-slate-700 hover:bg-slate-100"
                >
                  <GraduationCap className="w-4 h-4 text-emerald-600" />
                  <span>Switch to Student (Aarav)</span>
                </button>
                <button
                  onClick={() => handleRoleSwitch('faculty')}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs text-left rounded-lg text-slate-700 hover:bg-slate-100"
                >
                  <UserCheck className="w-4 h-4 text-amber-600" />
                  <span>Switch to Faculty (Prof. Priya)</span>
                </button>
                <button
                  onClick={() => handleRoleSwitch('admin')}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs text-left rounded-lg text-slate-700 hover:bg-slate-100"
                >
                  <ShieldCheck className="w-4 h-4 text-blue-900" />
                  <span>Switch to Admin (Dr. Ramesh)</span>
                </button>
              </div>

              <div className="p-1 border-t border-slate-100">
                <button
                  onClick={logout}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs text-rose-600 rounded-lg hover:bg-rose-50"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          )}
        </div>

      </div>

      {/* Supabase Cloud Connection Modal */}
      <SupabaseModal
        isOpen={supabaseModalOpen}
        onClose={() => {
          setSupabaseModalOpen(false);
          api.getSupabaseStatus().then(setSupabaseStatus).catch(console.error);
        }}
      />

    </header>
  );
}
