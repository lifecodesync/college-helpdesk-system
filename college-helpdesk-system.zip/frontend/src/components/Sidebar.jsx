import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Bot, 
  TicketCheck, 
  FileText, 
  Building2, 
  Bell, 
  BarChart3, 
  Users, 
  GraduationCap,
  Sparkles,
  ShieldCheck,
  HelpCircle
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Sidebar({ isOpen, setIsOpen }) {
  const { user } = useAuth();
  const role = user?.role || 'student';

  const navItems = [
    { name: 'Student Dashboard', path: '/', icon: LayoutDashboard, roles: ['student', 'faculty', 'admin'] },
    { name: 'AI Assistant (RAG)', path: '/chat', icon: Bot, roles: ['student', 'faculty', 'admin'], highlight: true },
    { name: 'Helpdesk Tickets', path: '/tickets', icon: TicketCheck, roles: ['student', 'faculty', 'admin'] },
    { name: 'Knowledge Base', path: '/documents', icon: FileText, roles: ['student', 'faculty', 'admin'] },
    { name: 'Departments & FAQs', path: '/departments', icon: Building2, roles: ['student', 'faculty', 'admin'] },
    { name: 'Campus Notices', path: '/notices', icon: Bell, roles: ['student', 'faculty', 'admin'] },
    { name: 'Analytics & Insights', path: '/analytics', icon: BarChart3, roles: ['faculty', 'admin'] },
    { name: 'User Management', path: '/admin/users', icon: Users, roles: ['admin'] },
  ];

  const filteredNav = navItems.filter(item => item.roles.includes(role));

  return (
    <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-200 shadow-sm transition-transform duration-300 md:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex flex-col h-full">
        
        {/* College Seal & Header */}
        <div className="flex items-center gap-3 px-5 h-16 border-b border-slate-200 bg-slate-50/80">
          <div className="w-10 h-10 rounded-xl bg-blue-900 text-white flex items-center justify-center shadow-md shadow-blue-900/20 font-bold flex-shrink-0">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div className="min-w-0">
            <h1 className="font-bold text-slate-900 text-sm tracking-tight truncate flex items-center gap-1.5">
              NIET EduAssist
            </h1>
            <p className="text-[10px] text-slate-500 font-medium truncate uppercase tracking-wider">
              Student Helpdesk Portal
            </p>
          </div>
        </div>

        {/* Institution Info Card */}
        <div className="px-4 py-3 bg-blue-50/60 border-b border-blue-100/80">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-semibold text-blue-950">Academic Year 2026-27</span>
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-emerald-200" title="System Active" />
          </div>
          <p className="text-[10px] text-blue-800/80 mt-0.5 truncate">National Institute of Eng. & Tech.</p>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Portal Navigation
          </div>
          {filteredNav.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className={({ isActive }) => `
                  flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all group
                  ${isActive 
                    ? 'bg-blue-50 text-blue-900 font-bold border-l-4 border-blue-800 shadow-sm' 
                    : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100/80'}
                `}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 transition-colors ${item.highlight ? 'text-blue-600 group-hover:scale-110' : ''}`} />
                  <span>{item.name}</span>
                </div>
                {item.highlight && (
                  <span className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-mono font-bold">
                    <Sparkles className="w-2.5 h-2.5" /> RAG
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Active Identity Card in Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50/60">
          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-white border border-slate-200 shadow-sm">
            <img 
              src={user?.avatar_url || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"} 
              alt={user?.full_name} 
              className="w-9 h-9 rounded-lg object-cover ring-2 ring-blue-100"
            />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-900 truncate">{user?.full_name || 'Loading...'}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className={`inline-block w-2 h-2 rounded-full ${
                  role === 'admin' ? 'bg-rose-500' : role === 'faculty' ? 'bg-amber-500' : 'bg-emerald-500'
                }`} />
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                  {role} Access
                </span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </aside>
  );
}
